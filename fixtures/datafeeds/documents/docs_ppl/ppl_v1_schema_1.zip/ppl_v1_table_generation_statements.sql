CREATE TABLE ppl_names (
 FACTSET_PERSON_ID CHAR(8) NOT NULL,
 people_name_type VARCHAR(35) NOT NULL,
 people_name_value VARCHAR(100) NOT NULL,
 PRIMARY KEY (FACTSET_PERSON_ID, people_name_type, people_name_value));
